package com.kevinlu.airquality;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;
import java.util.stream.Collectors;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    private Context context;
    private List<Station> stationList;

    public Adapter(Context context, List<Station> stationList) {
        this.context = context;
        this.stationList = stationList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.layout_listitem, null);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Station station = stationList.get(position);
        holder.textViewTitle.setText(station.getData().getCity());
//        List<Double> coordinates = station.getData().getLocation().getCoordinates();
//        String listString = coordinates.stream().map(Object::toString)
//                .collect(Collectors.joining(", "));
//        holder.textViewShortDesc.setText(listString);
        holder.textViewShortDesc.setText(decodePollutant(station.getData().getCurrent().getPollution().getMainus()));
        int aqius = station.getData().getCurrent().getPollution().getAqius();
        holder.textViewRating.setText(aqius + "");
        holder.textViewPrice.setText(rankAQIUS(aqius));
//        holder.imageView.setImageDrawable(context.getResources().getDrawable());
    }

    public String decodePollutant(String mainPollutant) {
        if (mainPollutant.equals("p2")) {
            return "PM 2.5";
        } else if (mainPollutant.equals("p1")) {
            return "PM 10";
        } else if (mainPollutant.equals("o3")) {
            return "Ozone";
        } else if (mainPollutant.equals("n2")) {
            return "Nitrogen Dioxide";
        } else if (mainPollutant.equals("s2")) {
            return "Sulfur Dioxide";
        } else if (mainPollutant.equals("co")) {
            return "Carbon Monoxide";
        } else {
            return "Unknown Pollutant";
        }
    }

    public String rankAQIUS(int aqius) {
        if (aqius >= 0 && aqius <= 50) {
            return "Good";
        } else if (aqius >= 51 && aqius <= 100) {
            return "Moderate";
        } else if (aqius >= 101 && aqius <= 150) {
            return "Unhealthy for Sensitive Groups";
        } else if (aqius >= 151 && aqius <= 200) {
            return "Unhealthy";
        } else if (aqius >= 201 && aqius <= 300) {
            return "Very Unhealthy";
        } else if (aqius >= 301) {
            return "Hazardous";
        } else {
            return "ERROR";
        }
    }

    @Override
    public int getItemCount() {
        return stationList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textViewTitle, textViewShortDesc, textViewRating, textViewPrice;

        public ViewHolder(View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.imageView);
            textViewTitle = itemView.findViewById(R.id.textViewTitle);
            textViewShortDesc = itemView.findViewById(R.id.textViewShortDesc);
            textViewRating = itemView.findViewById(R.id.textViewRating);
            textViewPrice = itemView.findViewById(R.id.textViewPrice);

        }
    }
}
