package com.kevinlu.airquality;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String url = "http://api.airvisual.com/v2/city?city=Mississauga&state=Ontario&country=Canada&key=ag85mSsqaj2Y24HvQ";
    private RecyclerView recyclerView;
    private Adapter adapter;
    private FileOutputStream fileOutputStream;

    private List<Station> stationList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        stationList = new ArrayList<>();

        loadRecyclerViewData();

        Pollution pollution1 = new Pollution();
        pollution1.setAqicn(10); pollution1.setAqius(100); pollution1.setMaincn("ASD"); pollution1.setMainus("DSD"); pollution1.setTs("xd");
        Weather weather1 = new Weather();
        weather1.setHu(100); weather1.setIc("ice"); weather1.setPr(14); weather1.setTp(51); weather1.setTs("xd"); weather1.setWd(12); weather1.setWs(21.21);

        List<Double> coords = new ArrayList<>();
        coords.add(40.7128); coords.add(74.0060);

        Location location1 = new Location();
        location1.setType("Point"); location1.setCoordinates(coords);

        Current current1 = new Current();
        current1.setPollution(pollution1);
        current1.setWeather(weather1);

        Data data1 = new Data();
        data1.setCity("City1"); data1.setCountry("Country1"); data1.setState("OK");
        data1.setCurrent(current1);
        data1.setLocation(location1);

        Station station1 = new Station();
        station1.setStatus("OK"); station1.setData(data1);

        Pollution pollution2 = new Pollution();
        pollution2.setAqicn(10); pollution2.setAqius(350); pollution2.setMaincn("ASD"); pollution2.setMainus("DSD"); pollution2.setTs("xd");
        Weather weather2 = new Weather();
        weather2.setHu(100); weather2.setIc("ice"); weather2.setPr(14); weather2.setTp(51); weather2.setTs("xd"); weather2.setWd(12); weather2.setWs(21.21);

        Location location2 = new Location();
        location2.setType("Point"); location2.setCoordinates(coords);

        Current current2 = new Current();
        current2.setPollution(pollution2);
        current2.setWeather(weather2);

        Data data2 = new Data();
        data2.setCity("City2"); data2.setCountry("Country2"); data2.setState("OK");
        data2.setCurrent(current2);
        data2.setLocation(location2);

        Station station2 = new Station();
        station2.setStatus("OK"); station2.setData(data2);

        stationList.add(station1);
        stationList.add(station2);
        stationList.add(station1);
        stationList.add(station2);
        stationList.add(station1);
        stationList.add(station2);
        stationList.add(station1);
        stationList.add(station2);
        stationList.add(station1);
        stationList.add(station2);
        stationList.add(station1);
        stationList.add(station2);
        stationList.add(station1);
        stationList.add(station2);
        stationList.add(station1);
        stationList.add(station2);

        adapter = new Adapter(this, stationList);

        recyclerView.setAdapter(adapter);

        Log.d("List Size", "" + stationList.size());
    }

    private void loadRecyclerViewData() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        fileOutputStream = null;
        //Request a string response from the provided URL, create a new StringRequest object
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //Using Gson to turn JSON to Java object of Station
                        //Create new GsonBuilder and Gson objects
                        GsonBuilder gsonBuilder = new GsonBuilder();
                        Gson gson = gsonBuilder.create();
                        //Create a new Station object and use Gson to deserialize JSON data
                        //into the Station object
                        Station station = gson.fromJson(response, Station.class);
                        //All file names are in the format of City.txt
                        String fileName = station.getData().getCity() + ".txt";
                        //Add the new Station object to the ArrayList of Station objects
                        //This is to create another entry in the RecyclerView
                        //Tell the RecyclerView adapter that our data is updated
                        //because Station was just to the ArrayList
                        stationList.add(station);
                        adapter.notifyDataSetChanged();
                        //openFileOutput will throw a FileNotFoundException so
                        //it is surrounded in a try - catch block to handle it
                        try {
                            //First try to open a file output, it has parameters
                            //of the file name and is set to MODE_PRIVATE so only
                            //the application can access it
                            fileOutputStream = openFileOutput(fileName, MODE_PRIVATE);
                            //Now the response from the API is written to the file
                            fileOutputStream.write(response.getBytes());
                            //Send a Toast to the user informing them that the data
                            //has been saved to a location on their device
                            Toast.makeText(getApplicationContext(), "Station " + station.getData().getCity()
                                    + " saved to: " + getFilesDir() + "/" + fileName, Toast.LENGTH_LONG).show();
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        } finally {
                            //Checking if fileOutputStream is not null
                            //then it has successfully saved the file to
                            //the file system of the device, again it is
                            //surrounded in a try - catch block because
                            //close() will throw a FileNotFoundException
                            if (fileOutputStream != null) {
                                try {
                                    fileOutputStream.close();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                        //Write the API response data to the log console
                        Log.d("API RESPONSE", response);
                    }
                }, new Response.ErrorListener() {
            //This is what will happen when there is an error during the response
            @Override
            public void onErrorResponse(VolleyError error) {
                //Write the error from Volley to the log console
                Log.d("VOLLEY ERROR", error.toString());
            }
        });
        //Add the request to the RequestQueue
        requestQueue.add(stringRequest);
    }
}
